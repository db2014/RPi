﻿#!/bin/bash

. ./PomocneSkripte/minifi.sh
##-----------------------------------------------------------------

#nano /etc/hosts add IP_add DockerContainerID
installMinifi
##-----------------------------------------------------------------
