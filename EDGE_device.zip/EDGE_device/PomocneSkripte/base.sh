﻿#!/bin/bash


. ./PomocneSkripte/putanje.sh


echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"
mkdir -p $pathRootFajlova
mkdir -p $pathMinifi

. ./PomocneSkripte/minifi.sh
createBootstrapConfFile
###################################################################################
echo "KRAJ PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"

