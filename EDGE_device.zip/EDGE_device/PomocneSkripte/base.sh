﻿#!/bin/bash


. ./PomocneSkripte/putanje.sh


echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"
mkdir -p $pathRootFajlova
mkdir -p $pathMinifi

. ./PomocneSkripte/minifi.sh
createBootstrapConfFile
createServiceAutoStartFile

systemctl daemon-reload
systemctl enable /etc/systemd/system/sample-on-boot-script.service
###################################################################################
echo "KRAJ PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"

