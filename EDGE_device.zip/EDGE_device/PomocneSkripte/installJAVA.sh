#!/bin/bash
#Start by updating your system packages

echo "UPDATE OS"
#instalacija jave
apt install default-jdk -y
echo 'export JAVA_HOME=/usr/lib/jvm/default-java' >> ~/.bash_profile
export JAVA_HOME=/usr/lib/jvm/default-java
echo "END UPDATE OS"
