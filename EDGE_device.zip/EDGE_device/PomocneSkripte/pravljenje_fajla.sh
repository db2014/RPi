#!/bin/bash

#first arg is name
#second arg is path
#threed arg is content

createFile(){
	echo "creating file $1 in $2"
        putanja=$2/$1
        cat << EOF > $putanja
$3
EOF
   	echo "end of creating $1 in $2"
}

