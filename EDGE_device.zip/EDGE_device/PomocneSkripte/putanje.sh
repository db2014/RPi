﻿#!/bin/bash

adresa=10.36.0.73
adresaC2Servera=10.36.0.73

pathRootFajlova="$PWD/fajloviZaMojuStriptu/"
pathMinifi="$PWD/fajloviZaMojuStriptu/minifi"
####################################################################################
##C2Server
portC2Nifi1=10080
template=iot-minifi-raspberry-agent
#ms
periodRefreshTemplate=10000

###################################################################################
