﻿#!/bin/bash

###https://www.2daygeek.com/execute-run-linux-scripts-command-at-reboot-startup/

###. /root/EDGE_device/PomocneSkripte/putanje.sh

/root/EDGE_device/fajloviZaMojuStriptu/minifi/minifi-0.5.0/bin/minifi.sh start

#mosquitto
