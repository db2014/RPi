#!/bin/bash

#. $PWD/1-runCreateFilesFolders.sh
#. $PWD/2-runUpdateOS.sh
#. $PWD/3-runInstallJAVA.sh
#. $PWD/4-runInstallMQTT.sh
#. $PWD/5-runMinifi.sh


temp_dir=$(pwd)
sh 1-runCreateFilesFolders.sh
sh 2-runUpdateOS.sh
sh 3-runInstallJAVA.sh
sh 4-runInstallMQTT.sh
sh 5-runMinifi.sh
chmod +x 6-runAutomatic.sh
sh 6-runAutomatic.sh
cd $temp_dir


