﻿#!/bin/bash

. ./PomocneSkripte/installJAVA.sh
