
#!/bin/bash


##ove komande posebno radi
##prva skripta...proveri da li je bilo gresaka prilokm instalacije
. ./PomocneSkripte/updateOS.sh






