#!/bin/bash

source ./base.sh

createMosquitoFiles(){
text="persistence true
persistence_location /mosquitto/data/
log_dest file /mosquitto/log/mosquitto.log"

createFile "mosquitto.conf" "$pathMosquito/config" "$text"
}

createMosquitoYMLfile(){
text="version: '2'

services:
##Mosquitto
  mqtt:
    container_name: mosquitto
    image: eclipse-mosquitto
    restart: always
    ports:
      - "$adresa:$portMosquito1:1883"
      - "$adresa:$portMosquito2:9001"
    volumes:
      - $pathMosquito/config:/mosquitto/config
      - $pathMosquito/data:/mosquitto/data
      - $pathMosquito/log:/mosquitto/log
volumes:
  config:
  data:
  log:"
  createFile "docker-compose.yml" "$pathMosquitoYML" "$text"
}

creteMosquitoFilesAfter(){
text="persistence true
persistence_location /mosquitto/data/
log_dest file /mosquitto/log/mosquitto.log
password_file /mosquitto/config/mosquitto.passwd

allow_anonymous false

listener 1883
listener 9001
protocol websockets"

createFile "mosquitto.conf" "$pathMosquito/config" "$text"
}

createMosquitoFiles
createMosquitoYMLfile
