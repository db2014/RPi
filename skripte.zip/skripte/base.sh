#!/bin/bash


adresa=192.168.240.131

portMosquito1=1884
portMosquito2=9002
pathMosquito="$PWD/fajloviZaMojuStriptu/mosquitto"
pathMosquitoYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/mosquitto"

portSiddhi=8006
pathSiddhi="$PWD/fajloviZaMojuStriptu/SiddhiKontejner"
pathSiddhiYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/sidhhi"

portPortainer=9000
pathPortainerYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/portainer"

portInflux=8086
pathInflux="$PWD/fajloviZaMojuStriptu/influxdb"
pathInfluxYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/influx"



echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA"
sudo mkdir -p $PWD/fajloviZaMojuStriptu/{ComposeFajlovi/{sidhhi,mosquitto,portainer,influx},mosquitto/{data,log,config},SiddhiKontejner,portainer,influxdb/{data,init}}

#first arg is name
#second arg is path
#threed arg is content

createFile(){
	echo "creating file $1 in $2"
        putanja=$2/$1
        cat << EOF > $putanja
$3
EOF
   	echo "end of creating $1 in $2"
}

