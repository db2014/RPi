#!/bin/bash
#Start by updating your system packages

echo "UPDATE OS"
sudo yum update
sudo yum upgrade
sudo yum install curl
echo "END UPDATE OS"
