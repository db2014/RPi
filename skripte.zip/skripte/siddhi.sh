#!/bin/bash

source ./base.sh

createSiddhiFiles(){
text="@App:name('CountOverTime')
@App:description('Receive events via HTTP, and logs the number of events received during last 15 seconds')

@source(type = 'http', receiver.url = "http://$adresa:$portSiddhi/production",
    @map(type = 'json'))
define stream ProductionStream (name string, amount double);

@sink(type = 'log')
define stream TotalCountStream (totalCount long);

-- Count the incoming events
@info(name = 'query1')
from ProductionStream#window.time(15 sec)
select count() as totalCount 
insert into TotalCountStream"

createFile "CountOverTime.siddhi" "$pathSiddhi" "$text"
}

createSiddhiYMLfile(){
text="
version: "3.3"
services: 
  siddhi-runner-alpine: 
    image: siddhiio/siddhi-runner-alpine
    ports: 
      - "$adresa:$portSiddhi:8006"
    volumes: 
      - $pathSiddhi/CountOverTime.siddhi:/apps/CountOverTime.siddhi"
	  
  createFile "docker-compose.yml" "$pathSiddhiYML" "$text"
}

createSiddhiFiles
createSiddhiYMLfile
