#u base.sh su sva podesavanja, osim sifre za influx
#u run.sh moze da se iskljuci deo koji nije porteban
