
#!/bin/bash

deleteAllBefore(){
        echo "brisanje predhodnih direktorujuma i kontejnera"
        sudo rm -rf $PWD/fajloviZaMojuStriptu
        docker stop $(docker ps -a -q)
        docker rm $(docker ps -a -q)
        docker system prune -a
        docker volume prune
}

deleteAllBefore

##all cnfigurations
source ./base.sh

#source ./updateOS.sh
#installDockerDockerCompose.sh
 
##prepare to docker-compose up 
source ./mosquito.sh
#source ./siddhi.sh
source ./portainer.sh 
source ./influx.sh

##run container

##-----------------------------------------------------------------
##-----------------------------------------------------------------
docker-compose -f $pathInfluxYML/docker-compose.yml up -d #radi
##-----------------------------------------------------------------
docker-compose -f $pathMosquitoYML/docker-compose.yml up -d #RADI
creteMosquitoFilesAfter
##-----------------------------------------------------------------
docker-compose -f $pathPortainerYML/docker-compose.yml up -d
docker restart portainer

