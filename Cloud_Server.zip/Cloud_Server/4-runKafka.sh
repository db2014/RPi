#!/bin/bash

. ./PomocneSkripte/putanje.sh
##-----------------------------------------------------------------
docker-compose -f $pathKafkaYML/docker-compose.yml up -d
##-----------------------------------------------------------------
