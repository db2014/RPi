#!/bin/bash

. ./PomocneSkripte/pravljenje_fajla.sh

createKafkaYMLfile(){
text="version: '3'
services:
  zookeeper:
    image: wurstmeister/zookeeper
    container_name: zookeeperDusan
    ports:
      - '$adresa:$kafkaZookeeprer:2181'
  kafka:
    image: wurstmeister/kafka
    ports:
      - '$adresa:$kafkaPort:9092'
    environment:
      KAFKA_ADVERTISED_HOST_NAME: $adresa
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock"  
  createFile "docker-compose.yml" "$pathKafkaYML" "$text"
}





