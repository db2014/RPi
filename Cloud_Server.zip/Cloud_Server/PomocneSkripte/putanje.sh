﻿#!/bin/bash

adresa=10.36.0.73

pathRootFajlova="$PWD/fajloviZaMojuStriptu/"

####################################################################################
##NifiServer
pathNifi="$PWD/fajloviZaMojuStriptu/Nifi"
pathNifiYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/nifi"
portNifi1=8080
portNifi2=8081
###################################################################################
####################################################################################
##KafkaServer
pathKafka="$PWD/fajloviZaMojuStriptu/Kafka"
pathKafkaYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/kafka"
kafkaZookeeprer=2181
kafkaPort=9092
####################################################################################
##influxdb
pathInflux="$PWD/fajloviZaMojuStriptu/influxdb"
pathInfluxYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/influx"

portInflux=8086
###################################################################################
