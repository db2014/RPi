﻿#!/bin/bash

adresa=10.36.0.98

pathRootFajlova="$PWD/fajloviZaMojuStriptu/"

####################################################################################
##NifiServer
pathNifi="$PWD/fajloviZaMojuStriptu/Nifi"
pathNifiYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/nifi"
portNifi1=8080
portNifi2=8081
###################################################################################
####################################################################################
##influxdb
pathInflux="$PWD/fajloviZaMojuStriptu/influxdb"
pathInfluxYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/influx"

portInflux=8086
###################################################################################
