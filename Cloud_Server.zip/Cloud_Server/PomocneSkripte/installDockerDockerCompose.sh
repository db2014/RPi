#!/bin/bash
apt-get install curl -y
apt install apt-transport-https ca-certificates curl gnupg2 software-properties-common -y
curl -fsSL https://download.docker.com/linux/debian/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"
apt update -y
apt-cache policy docker-ce
apt install docker-ce -y
systemctl start docker
systemctl enable docker
usermod -aG docker $USER
curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/bin/docker-compose
chmod +x /usr/bin/docker-compose
sysctl net.ipv4.conf.all.forwarding=1
iptables -P FORWARD ACCEPT
