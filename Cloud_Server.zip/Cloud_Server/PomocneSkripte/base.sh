﻿#!/bin/bash


. ./PomocneSkripte/putanje.sh


echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"
mkdir -p $pathRootFajlova

##Folder i koju su potrebni za Compose
mkdir -p $pathRootFajlova/ComposeFajlovi/

####################################################################################
##NifiServer
mkdir -p $pathNifiYML
. ./PomocneSkripte/nifi.sh
createNifiYMLfile
####################################################################################
##influxdb
mkdir -p $pathInfluxYML
mkdir -p $pathInflux/data
mkdir -p $pathInflux/init

. ./PomocneSkripte/influx.sh
createInfluxYMLfile
###################################################################################
echo "KRAJ PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"

