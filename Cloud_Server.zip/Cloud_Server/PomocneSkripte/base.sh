﻿#!/bin/bash


. ./PomocneSkripte/putanje.sh


echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"
mkdir -p $pathRootFajlova

##Folder i koju su potrebni za Compose
mkdir -p $pathRootFajlova/ComposeFajlovi/

####################################################################################
##NifiServer
mkdir -p $pathNifiYML
. ./PomocneSkripte/nifi.sh
createNifiYMLfile
####################################################################################
##KafkaServer
mkdir -p $pathKafkaYML
. ./PomocneSkripte/kafka.sh
createKafkaYMLfile
####################################################################################
##influxdb
mkdir -p $pathInfluxYML
. ./PomocneSkripte/influx.sh
createInfluxYMLfile
createTelegrafConfFile
###################################################################################
echo "KRAJ PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"

