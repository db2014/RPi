#!/bin/bash

. ./PomocneSkripte/pravljenje_fajla.sh


createNifiYMLfile(){
text="version: '3.3'
services:
    nifi:
        container_name: nifi
        ports:
            - '$adresa:$portNifi1:8080'
            - '$adresa:$portNifi1:8081'
        environment:
            - NIFI_WEB_HTTP_PORT=8080
        image: 'apache/nifi:latest'"  
  createFile "docker-compose.yml" "$pathNifiYML" "$text"
}





