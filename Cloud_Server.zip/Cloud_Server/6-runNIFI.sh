﻿#!/bin/bash

. ./PomocneSkripte/putanje.sh
##-----------------------------------------------------------------
docker-compose -f $pathNifiYML/docker-compose.yml up -d
##-----------------------------------------------------------------
