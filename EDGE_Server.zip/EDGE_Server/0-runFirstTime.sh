#!/bin/bash

. $PWD/1-runCreateFilesFolders.sh
. $PWD/2-runUpdateOS.sh
. $PWD/3-runInstallDocker.sh
. $PWD/4-runInstallJava.sh
. $PWD/5-runInflux.sh
. $PWD/6-runNIFI-C2-Server.sh


temp_dir=$(pwd)
sh 1-runCreateFilesFolders.sh
sh 2-runUpdateOS.sh
sh 3-runInstallDocker.sh
sh 4-runInstallJava.sh
sh 5-runInflux.sh
cd $temp_dir
sh 6-runNIFI-C2-Server.sh


