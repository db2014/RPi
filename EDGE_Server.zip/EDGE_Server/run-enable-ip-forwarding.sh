
#!/bin/bash

sysctl net.ipv4.conf.all.forwarding=1
iptables -P FORWARD ACCEPT
reboot
