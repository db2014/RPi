
#!/bin/bash

##druga skripta...proveri da li je bilo gresaka prilokm instalacije
. ./PomocneSkripte/installDockerDockerCompose.sh





