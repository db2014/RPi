#!/bin/bash

. ./PomocneSkripte/pravljenje_fajla.sh

createMinifiC2ContextFile(){
text="<beans default-lazy-init='true'
       xmlns='http://www.springframework.org/schema/beans'
       xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'
       xsi:schemaLocation='http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.1.xsd'>

    <bean id='configService' class='org.apache.nifi.minifi.c2.service.ConfigService' scope='singleton'>
        <constructor-arg>
            <list>
	                <bean class='org.apache.nifi.minifi.c2.provider.nifi.rest.NiFiRestConfigurationProvider'>
                    <constructor-arg>
                        <bean class='org.apache.nifi.minifi.c2.cache.filesystem.FileSystemConfigurationCache'>
                            <constructor-arg>
                                <value>./cache</value>
                            </constructor-arg>
                            <constructor-arg>
                                <value>\${class}/\${class}</value>
                            </constructor-arg>
                        </bean>
                    </constructor-arg>
                    <constructor-arg>
                        <value>http://$adresaNifiServera:8080/nifi-api</value>
                    </constructor-arg>
                    <constructor-arg>
                        <value>\${class}.v\${version}</value>
                    </constructor-arg>
                </bean>
            </list>
        </constructor-arg>
        <constructor-arg>
            <bean class='org.apache.nifi.minifi.c2.security.authorization.GrantedAuthorityAuthorizer'>
                <constructor-arg value='classpath:authorizations.yaml'/>
            </bean>
        </constructor-arg>
    </bean>
</beans>"  
  createFile "minifi-c2-context.xml" "$pathC2Server" "$text"
}

getMinfi(){
	cd $pathC2Server
	wget http://archive.apache.org/dist/nifi/minifi/0.5.0/minifi-c2-0.5.0-bin.tar.gz
	tar -xvf minifi-c2-0.5.0-bin.tar.gz
    rm minifi-c2-0.5.0-bin.tar.gz
    rm $pathC2Server/minifi-c2-0.5.0/conf/minifi-c2-context.xml	
	cp $pathC2Server/minifi-c2-context.xml $pathC2Server/minifi-c2-0.5.0/conf/minifi-c2-context.xml
}
runMinifi(){
	cd $pathC2Server
	./minifi-c2-0.5.0/bin/c2.sh
}







