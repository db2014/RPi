﻿#!/bin/bash


. ./PomocneSkripte/putanje.sh


echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"
mkdir -p $pathRootFajlova

##Folder i koju su potrebni za Compose
mkdir -p $pathRootFajlova/ComposeFajlovi/
##Folder i koju su potrebni za NifiC2Server
mkdir -p $pathRootFajlova/NifiC2Server/

####################################################################################
##C2Server

####################################################################################
##influxdb
mkdir -p $pathInfluxYML
mkdir -p $pathInflux/data
mkdir -p $pathInflux/init

. ./PomocneSkripte/influx.sh
createInfluxYMLfile
###################################################################################
echo "KRAJ PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"

