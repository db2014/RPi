﻿#!/bin/bash


. ./PomocneSkripte/putanje.sh


echo "PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"
sudo mkdir -p $pathRootFajlova

##Folder i koju su potrebni za Compose
sudo mkdir -p $pathRootFajlova/ComposeFajlovi/


####################################################################################
##influxdb
sudo mkdir -p $pathInfluxYML
sudo mkdir -p $pathInflux/data
sudo mkdir -p $pathInflux/init

. ./PomocneSkripte/influx.sh
createInfluxYMLfile
###################################################################################
echo "KRAJ PRAVLJENJE OSNOVNIH DIREKTORIJUMA I FAJLOVA"

