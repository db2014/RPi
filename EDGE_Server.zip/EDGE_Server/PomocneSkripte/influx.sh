#!/bin/bash

. ./PomocneSkripte/pravljenje_fajla.sh

#pathInflux
createInfluxdbConfFile(){
cd $pathInflux 
#za verziju influx2
docker run --rm influxdb influxd print-config > influxdb.conf
sed -i 's/^  auth-enabled = false$/  auth-enabled = true/g' influxdb.conf
cd $pathInflux
}

createTelegrafConfFile(){
cd $pathInflux 
docker run --rm telegraf telegraf config > telegraf.conf
# now modify it to tell it how to authenticate against influxdb
sed -i 's/^  # urls = \["http:\/\/127\.0\.0\.1:8086"\]$/  urls = \["http:\/\/influxdb:8086"\]/g' telegraf.conf
sed -i 's/^  # database = "telegraf"$/  database = "telegraf"/' telegraf.conf
sed -i 's/^  # username = "telegraf"$/  username = "telegraf"/' telegraf.conf
sed -i 's/^  # password = "metricsmetricsmetricsmetrics"$/  password = "P@ssw0rd"/' telegraf.conf
# as we run inside docker, the telegraf hostname is different from our Raspberry hostname, let's change it
#sed -i 's/^  hostname = ""$/  hostname = "'${HOSTNAME}'"/' telegraf.conf
}

createInfluxYMLfile(){
text="version: '3'

networks:
  metrics:
    external: false

services:
  influxdb:
    image: influxdb:latest
    container_name: influxdb
    restart: always
    networks: [metrics]
    ports:
      - '$adresa:$portInflux:8086'
    volumes:
      - $pathInflux/data:/var/lib/influxdb
      - $pathInflux/influxdb.conf:/etc/influxdb/influxdb.conf:ro
      - $pathInflux/init:/docker-entrypoint-initdb.d
    environment:
      - INFLUXDB_ADMIN_USER=admin
      - INFLUXDB_ADMIN_PASSWORD=P@ssw0rd
  telegraf:
    image: telegraf:latest
    restart: always
    container_name: telegraf
    networks: [metrics]
    volumes:
      - $pathInflux/telegraf.conf:/etc/telegraf/telegraf.conf:ro
  chronograf:
    container_name: chronograf
    restart: always
    image: chronograf:latest
    ports:
      - '127.0.0.1:8888:8888'
    depends_on:
      - influxdb
    networks: [metrics]
    environment:
      - INFLUXDB_URL=http://influxdb:8086 # needs to match container_name
      - INFLUXDB_USERNAME=admin
      - INFLUXDB_PASSWORD=P@ssw0rd"  
  createFile "docker-compose.yml" "$pathInfluxYML" "$text"
}

createInfluxSQLtelegraf(){
text="
CREATE DATABASE telegraf WITH DURATION 31d
CREATE USER telegraf WITH PASSWORD 'P@ssw0rd'
GRANT WRITE ON telegraf to telegraf"

  createFile "create-telegraf.iql" "$pathInfluxYML/init" "$text"
}





