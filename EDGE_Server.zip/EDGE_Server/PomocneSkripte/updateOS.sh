#!/bin/bash
#Start by updating your system packages

echo "UPDATE OS"
apt-get update
apt-get upgrade -y
apt-get install curl 
echo "END UPDATE OS"
