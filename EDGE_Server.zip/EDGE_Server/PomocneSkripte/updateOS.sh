#!/bin/bash
#Start by updating your system packages

echo "UPDATE OS"
apt-get update
apt-get upgrade -y
apt-get install curl -y
echo "END UPDATE OS"
