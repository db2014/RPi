#!/bin/bash

##1
##-----------------------------------------------------------------------------------------------------------------
##Install the required dependencies
echo "INSTALIARM POTREBNE PAKETE"

sudo apt install apt-transport-https ca-certificates curl gnupg2 software-properties-common -y
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"
sudo apt update -y
apt-cache policy docker-ce

echo "ZAVRSENO INSTALIRANJE POTREBNIH PAKETA"

##-----------------------------------------------------------------------------------------------------------------
##3
##-----------------------------------------------------------------------------------------------------------------
##Install the latest version of Docker CE (Community Edition) 
echo "INSTALIARM DOCKER"
sudo apt install docker-ce -y
echo "ZAVRSENO INSTALIRANJE DOCKERA"
##-----------------------------------------------------------------------------------------------------------------
##4
##-----------------------------------------------------------------------------------------------------------------
##Start the Docker daemon and enable it to automatically start at boot time
echo "PODESAVAM DOCKER"
sudo systemctl start docker
sudo systemctl enable docker

##If you want to run Docker commands as a non-root user 
##without prepending sudo you need to add your user to the docker group
sudo usermod -aG docker $USER
echo "ZAVRSENO PODESAVANJE DOCKERA"
#-----------------------------------------------------------------------------------------------------------------
#5
#-----------------------------------------------------------------------------------------------------------------
#instalacija docker-compose
#proveri koja je poslednja verzija, sada je 1.29.2
echo "INSTALIARM DOCKER-COMPOSE"
sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/bin/docker-compose
sudo chmod +x /usr/bin/docker-compose
echo "ZAVRSENO INSTALIARANJE DOCKER-COMPOSE"
#---------------------------------------------------------------------------------------------------------------
