﻿#!/bin/bash


adresa=10.36.0.98

pathRootFajlova="$PWD/fajloviZaMojuStriptu/"

####################################################################################
##influxdb
pathInflux="$PWD/fajloviZaMojuStriptu/influxdb"
pathInfluxYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/influx"

portInflux=8086
###################################################################################
