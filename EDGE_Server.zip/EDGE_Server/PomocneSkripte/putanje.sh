﻿#!/bin/bash

adresaNifiServera=10.36.0.42
adresa=10.36.0.98

pathRootFajlova="$PWD/fajloviZaMojuStriptu/"

####################################################################################
##C2Server
pathC2Server="$PWD/fajloviZaMojuStriptu/NifiC2Server"
###################################################################################
####################################################################################
##influxdb
pathInflux="$PWD/fajloviZaMojuStriptu/influxdb"
pathInfluxYML="$PWD/fajloviZaMojuStriptu/ComposeFajlovi/influx"

portInflux=8086
###################################################################################
