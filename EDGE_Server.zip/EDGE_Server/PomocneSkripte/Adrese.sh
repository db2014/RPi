﻿#!/bin/bash


adresaNifiServera=10.36.0.98
