﻿#!/bin/bash

. ./PomocneSkripte/putanje.sh
. ./PomocneSkripte/C2Server.sh
##-----------------------------------------------------------------
#createMinifiC2ContextFile
#getMinfi
#runMinifi
runDockerConatiner
##-----------------------------------------------------------------
