﻿
#!/bin/bash

. ./PomocneSkripte/putanje.sh
. ./PomocneSkripte/C2Server.sh
##-----------------------------------------------------------------
createMinifi-c2-contextFile
getMinfi
runMinifi
##-----------------------------------------------------------------
