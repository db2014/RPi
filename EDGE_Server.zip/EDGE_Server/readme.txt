
Ova sktripra isntalira:
	Docker, Docker-compose
	Java-defalut
	INFLUXv2 kao Docker  
	C2Server preko fajlova

!!!proveri IP adrese da li su dobre u PomocneSktipte/putanje.sh