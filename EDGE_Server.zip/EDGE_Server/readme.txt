
Ova sktripra isntalira:
	Docker, Docker-compose
	Java-defalut
	INFLUXv2 kao Docker  
	C2Server preko fajlova #nece da radi na Debian11 ,vrv zbog jave...do sada je radilo na Debina9
	nece zato sto sktipta ne pravi dobar .xml fajl za konfigurisanje
	izbaci ti ${class}
${class}.v${version}
${class}/${class}
	ako rucno to prepravis minifi-c2-context.xml...onda ce raditi


!!!proveri IP adrese da li su dobre u PomocneSktipte/putanje.sh