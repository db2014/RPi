##
##Ova sktripra isntalira:
##	Docker, Docker-compose
##	Java-defalut
##	INFLUXv2 kao Docker  
##	C2Server preko fajlova #nece da radi na Debian11 ,vrv zbog jave...do sada je radilo na Debina9
##	C2Server kao Docker 
##!!!proveri IP adrese da li su dobre u PomocneSktipte/putanje.sh
##napravi novu sktiptu sa nano skripta1.sh
##stavi ovaj tekst u nju
##promeni ekstenziju sa chmod +x
##pokreni je sa sh skripta1.sh

#!/bin/bash
apt-get install p7zip-full -y
mkdir brisi
temp_dir=$(pwd)
cd brisi
if wget https://github.com/db2014/RPi/archive/refs/heads/main.zip; then
        echo "preuzeto"
        if 7z e main.zip; then
                cp EDGE_Server.zip $temp_dir
                cd $temp_dir
                rm -rf  brisi
                if 7z x EDGE_Server.zip; then
                        rm EDGE_Server.zip
                else 
                        echo "greska pri raspakivanju EDGE_server.zip"
                fi
        else
                echo  "grreska pri raspakivanju main.zip"
        fi
else
        echo "Doslo je do greske pri preuzimanju"
fi

echo "SET properly IP add in $temp_dir/EDGE_Server/PomocneSkripte/putanje.sh"
echo "RUNNING ALL SCRIPTS with this command sh $temp_dir/EDGE_Server/0-runFirstTime"


