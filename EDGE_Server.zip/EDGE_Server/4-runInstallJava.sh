
#!/bin/bash

apt install default-jdk -y
echo 'export JAVA_HOME=/usr/lib/jvm/default-java' >> ~/.bash_profile
export JAVA_HOME=/usr/lib/jvm/default-java






