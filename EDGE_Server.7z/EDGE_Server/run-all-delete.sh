
#!/bin/bash

. ./PomocneSkripte/putanje.sh

deleteAllBefore(){
        echo "brisanje predhodnih direktorujuma i kontejnera"
        sudo rm -rf $pathRootFajlova
        docker stop $(docker ps -a -q)
        docker rm $(docker ps -a -q) 
        docker system prune -a 
        docker volume prune 
}



deleteAllBefore




