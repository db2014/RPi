
#!/bin/bash

. ./PomocneSkripte/putanje.sh
. ./PomocneSkripte/influx.sh
##-----------------------------------------------------------------
createInfluxdbConfFile
createTelegrafConfFile
sudo docker-compose -f $pathInfluxYML/docker-compose.yml up -d
##-----------------------------------------------------------------
