#!/bin/bash
#Start by updating your system packages

echo "UPDATE OS"
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install curl 
echo "END UPDATE OS"
