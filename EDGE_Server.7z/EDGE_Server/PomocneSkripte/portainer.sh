#!/bin/bash

. ./PomocneSkripte/pravljenje_fajla.sh

createPortainerVolume(){
docker volume create portainer_data
}

createPortainerYMLfile(){
text="version: '3.2'

services:
  agent:
    image: portainer/agent
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - /var/lib/docker/volumes:/var/lib/docker/volumes

  portainer:
    image: portainer/portainer-ce
    command: -H tcp://agent:9001 --tlsskipverify
    container_name: portainer
    ports:
      - '$adresa:$portPortainer:9000'
    volumes:
      - portainer_data:/data

volumes:
  portainer_data:"
  
  createFile "docker-compose.yml" "$pathPortainerYML" "$text"
}

