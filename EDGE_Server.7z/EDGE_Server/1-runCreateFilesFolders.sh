
#!/bin/bash

##svi inicijalni fajlovi i folderi se prave
. $PWD/PomocneSkripte/base.sh







