﻿
#!/bin/bash
##-----------------------------------------------------------------
#idi na locahhost:8080\nifi
sudo docker run --name nifi \
  -p 8080:8080 \
  -p 8081:8081 \
  -d \
  -e NIFI_WEB_HTTP_PORT='8080' \
  apache/nifi:latest
##-----------------------------------------------------------------
